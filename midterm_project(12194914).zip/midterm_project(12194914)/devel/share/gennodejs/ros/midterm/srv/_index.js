
"use strict";

let WeatherStation = require('./WeatherStation.js')

module.exports = {
  WeatherStation: WeatherStation,
};
