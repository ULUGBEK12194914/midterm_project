// Auto-generated. Do not edit!

// (in-package midterm.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class WeatherStationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.GPS_location = null;
    }
    else {
      if (initObj.hasOwnProperty('GPS_location')) {
        this.GPS_location = initObj.GPS_location
      }
      else {
        this.GPS_location = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type WeatherStationRequest
    // Serialize message field [GPS_location]
    bufferOffset = _serializer.string(obj.GPS_location, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type WeatherStationRequest
    let len;
    let data = new WeatherStationRequest(null);
    // Deserialize message field [GPS_location]
    data.GPS_location = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.GPS_location);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'midterm/WeatherStationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7319c1b0fe7d76efda9da2a2ab474520';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string GPS_location
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new WeatherStationRequest(null);
    if (msg.GPS_location !== undefined) {
      resolved.GPS_location = msg.GPS_location;
    }
    else {
      resolved.GPS_location = ''
    }

    return resolved;
    }
};

class WeatherStationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.weather_type = null;
    }
    else {
      if (initObj.hasOwnProperty('weather_type')) {
        this.weather_type = initObj.weather_type
      }
      else {
        this.weather_type = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type WeatherStationResponse
    // Serialize message field [weather_type]
    bufferOffset = _serializer.string(obj.weather_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type WeatherStationResponse
    let len;
    let data = new WeatherStationResponse(null);
    // Deserialize message field [weather_type]
    data.weather_type = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.weather_type);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'midterm/WeatherStationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b3cb833777ee411ab52dc92c5d819945';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string weather_type
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new WeatherStationResponse(null);
    if (msg.weather_type !== undefined) {
      resolved.weather_type = msg.weather_type;
    }
    else {
      resolved.weather_type = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: WeatherStationRequest,
  Response: WeatherStationResponse,
  md5sum() { return '2bff61a9c9a2b74475ab3a9d9c65ce3d'; },
  datatype() { return 'midterm/WeatherStation'; }
};
